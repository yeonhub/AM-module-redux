import React from 'react';
import Staff from './staff/Staff';

const App = () => {
  return (
    <div>
      <Staff/>
    </div>
  );
};

export default App;