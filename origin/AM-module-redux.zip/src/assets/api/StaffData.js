export default [
    { id: 1, name: '펭귄', img: './images/img0.png', job: '어부', tel: '010-4521-1313', like: false},
    { id: 2, name: '악어', img: './images/img1.png', job: '목수', tel: '010-2342-1313', like: false},
    { id: 3, name: '삑삑이', img: './images/img2.png', job: '경찰', tel: '010-2136-1313', like: false},
    { id: 4, name: '루피', img: './images/img3.png', job: '대장장이', tel: '010-1122-1313', like: false},
    { id: 5, name: '누렁이', img: './images/img4.png', job: '전사', tel: '010-8955-1313', like: false},
    { id: 6, name: '북극곰', img: './images/img5.png', job: '가수', tel: '010-6112-1313', like: false}
]